package com.capgemini.java.service;

import java.util.List;
import java.util.Map;

import com.capgemini.java.bean.Account;
import com.capgemini.java.bean.Transaction;
import com.capgemini.java.dao.BankDao;
import com.capgemini.java.dao.BankDaoImpl;

public class BankServiceImpl implements BankService {
	BankDao dao=new BankDaoImpl();

	@Override
	public long addDetails(Account account) {
		long accountNo=(long)(Math.random()*100000000);
		account.setAccountNo(accountNo);
		
		return dao.addDetails(account);
	}

	@Override
	public Map<Long, Account> accountDetails(Account account) {
		
		return dao.accountDetails(account);
	}

	@Override
	public long addDeposit(long accountNo, long depositAmount) {
		
		return dao.addDeposit(accountNo, depositAmount);
	}

	@Override
	public long addWithDraw(long accountNo, long withDrawAmount) {
		
		return dao.addWithDraw(accountNo, withDrawAmount);
	}

	@Override
	public double balanceCheck() {
		
		return dao.balanceCheck();
	}

	@Override
	public long fundDetails(long accountNo, long fundAmount) {
		
		return dao.fundDetails(accountNo, fundAmount);
	}

	@Override
	public int addTransaction(Transaction transaction) {
		int id=(int)(Math.random()*1000);
		transaction.setTransactionId(id);
		return dao.addTransaction(transaction);
	}

	@Override
	public Map<Integer, Transaction> transactionDetails(Transaction transaction) {
		
		return dao.transactionDetails(transaction);
	}

	@Override
	public List<Transaction> allTransactionDetails() {
		
		return dao.allTransactionDetails();
	}

}
