package com.capgemini.java.dao;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.capgemini.java.bean.Account;
import com.capgemini.java.bean.Transaction;

public interface BankDao {
long addDetails(Account account);
Map<Long,Account> accountDetails(Account account);
long addDeposit(long accountNo,long depositAmount);
long addWithDraw(long accountNo,long withDrawAmount);
 double balanceCheck();
 long fundDetails(long accountNo,long fundAmount);
 int addTransaction(Transaction transaction);
 Map<Integer, Transaction> transactionDetails(Transaction transaction);
 List<Transaction> allTransactionDetails();

}
